# IMX296 ISP Binary Package v0.2c

This package installs an experimental IMX296 `camera_overrides.isp` for Jetson Argus.

The ISP file is derived from a known Jetson IMX477 `camera_overrides.isp` template with Raspberry Pi IMX296 black level and daylight CCM mapped in. Version v0.2c removes the IMX477 lens shading surface/control-point tables, keeps lens shading disabled, reduces saturation, and uses a conservative CCM to reduce the yellow/warm cast observed during testing.

This is not final production tuning; validate image quality before shipping it to end customers.

## Install

```bash
cd scripts
chmod +x install_isp.sh rollback_isp.sh
./install_isp.sh
```

The installer writes:

```text
/var/nvidia/nvcam/settings/camera_overrides.isp
```

If an existing ISP override is present, it is backed up under:

```text
/var/nvidia/nvcam/settings/backup_imx296_isp/
```

The installer restarts `nvargus-daemon` automatically. A full system reboot is normally not required.

## Roll Back

```bash
cd scripts
./rollback_isp.sh
```

Rollback behavior:

- If a previous `camera_overrides.isp` was backed up during install, it is restored.
- If no previous override existed, the installed IMX296 override is removed.
- `nvargus-daemon` is restarted automatically.

## Notes

- Close all camera applications before install or rollback.
- Use this package only with the verified IMX296 driver/DTBO baseline.
- If preview does not change after install, restart camera applications first, then restart `nvargus-daemon`, then reboot only if needed.
- v0.3 GTM/highlight curve testing was rejected by Argus, so this package does not modify global tone map control points.
- v0.2d no-AWB testing made the yellow cast worse, so this package keeps the AWB section from v0.2c.
