#!/bin/bash
# Select which IMX296 mono (Y10) overlay boots: cam0 | cam1 | dual.
# Rewrites the camera overlay entry on the OVERLAYS line of extlinux.conf,
# then a reboot applies it. Does not touch the 40-pin header overlay.
set -euo pipefail

SEL="${1:-}"
case "$SEL" in
    cam0|cam1|dual) ;;
    *) echo "Usage: sudo $0 cam0|cam1|dual"; exit 1 ;;
esac

CONF=/boot/extlinux/extlinux.conf
NEW="tegra234-p3767-camera-p3768-imx296mono-${SEL}.dtbo"

[ -f "/boot/${NEW}" ] || { echo "ERROR: /boot/${NEW} not found (run install first)"; exit 1; }
[ -f "$CONF" ]        || { echo "ERROR: $CONF not found"; exit 1; }

sudo cp -a "$CONF" "${CONF}.imx296mono.bak"

# Replace any existing imx296 / imx296mono camera dtbo token with the chosen one.
if grep -qE 'tegra234-p3767-camera-p3768-imx296[^,[:space:]]*\.dtbo' "$CONF"; then
    sudo sed -i -E "s#tegra234-p3767-camera-p3768-imx296[^,[:space:]]*\.dtbo#${NEW}#g" "$CONF"
    echo "Switched camera overlay to: ${NEW}"
else
    echo "No existing imx296 overlay token found on an OVERLAYS line."
    echo "Add it manually to /boot/extlinux/extlinux.conf, e.g.:"
    echo "  OVERLAYS /boot/${NEW}"
    exit 1
fi

echo "Backup saved: ${CONF}.imx296mono.bak"
echo "Reboot to apply: sudo reboot"
