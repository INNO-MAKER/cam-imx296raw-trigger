# scripts/

| Script                  | Purpose                                                          |
|-------------------------|------------------------------------------------------------------|
| `camera_control_mono.sh`| Raw V4L2 capture/preview of Y10 grayscale (`capture` \| `preview`). |
| `switch_cam_overlay.sh` | Select boot overlay: `cam0` \| `cam1` \| `dual` (then reboot).    |
| `rollback_y10.sh`       | Restore modules + overlays from an `/opt/imx296-mono-backup-*` dir. |

Mono uses the **raw V4L2 path** (no Argus, no ISP). There is no `install_isp.sh`.

```bash
# capture one frame to .raw/.pgm/.png
DEVICE=/dev/video0 ./camera_control_mono.sh capture cam0_y10
# live preview window (needs OpenCV + display)
DEVICE=/dev/video0 ./camera_control_mono.sh preview
```
