# IMX296 Mono (Y10) Binary Package (working) — 20260615

Prebuilt IMX296LLR **monochrome** camera support for NVIDIA Jetson Orin
Nano/NX, L4T r36.4.4 / JetPack 6, kernel `5.15.148-tegra` (T234).

The V4L2 format is reported as grayscale **`Y10`** (10-bit). The mono path is
pure **raw V4L2** — it does **not** use Argus or an ISP override.

This package contains the sensor module, a Y10-patched `tegra-camera.ko`, and
three device-tree overlays (cam0 / cam1 / dual).

## Contents

```
binary/imx296.ko            Kernel sensor driver (release build, stripped)
binary/tegra-camera.ko      Tegra VI driver patched for Y10 (stripped)
overlays/                   Device-tree overlays:
    ...-imx296mono-cam0.dtbo  cam0 only  (CSI cam A, serial_b)
    ...-imx296mono-cam1.dtbo  cam1 only  (CSI cam C, serial_c)
    ...-imx296mono-dual.dtbo  both cameras
install_binary.sh           Installs modules + all three overlays
scripts/                    Capture / overlay-switch / rollback helpers
develop/                    On-device verification helper
```

The dual overlay is byte-identical to the previously hardware-verified
`imx296_mono_y10_*_20260523_v1_0` overlay. The cam0/cam1 single overlays reuse
the hardware-verified color single-camera structure with mono fields
(`compatible = sony,imx296ll`, `pixel_t = mono_y10`).

## Install

```bash
./install_binary.sh                       # imx296.ko + tegra-camera.ko + overlays
sudo scripts/switch_cam_overlay.sh dual   # choose: dual | cam0 | cam1
sudo reboot
```

## Capture / preview

```bash
# verify a frame streams
bash develop/verify_mono.sh /dev/video0

# raw Y10 capture (.raw/.pgm/.png) and live preview
DEVICE=/dev/video0 scripts/camera_control_mono.sh capture cam0_y10
DEVICE=/dev/video0 scripts/camera_control_mono.sh preview
```

Expected format from `v4l2-ctl -d /dev/video0 --list-formats-ext`:

```
Y10  10-bit Greyscale
```

## Notes

- Both modules are built for `5.15.148-tegra` only.
- No ISP: mono is raw V4L2; there is no color tuning step.
- `tegra-camera.ko` is NVIDIA's GPL VI driver rebuilt with the Y10 format
  patch; it must replace the stock module for Y10 to appear.
- Roll back with `scripts/rollback_y10.sh /opt/imx296-mono-backup-<timestamp>`.
