# IMX296 Mono (Y10) — User Manual

Target: Jetson Orin Nano/NX, L4T r36.4.4 / JetPack 6, kernel 5.15.148-tegra.
Sensor format: 1456x1088, **Y10** (10-bit grayscale), up to ~60 fps.
Path: raw V4L2 (no Argus / no ISP).

## 1. Install

```bash
./install_binary.sh
```

Installs `imx296.ko`, the Y10-patched `tegra-camera.ko`, and the three overlays
into `/boot`. A rollback copy is saved under `/opt/imx296-mono-backup-<ts>`.

## 2. Choose a camera configuration

```bash
sudo scripts/switch_cam_overlay.sh dual    # both CSI cameras  -> /dev/video0,1
sudo scripts/switch_cam_overlay.sh cam0    # cam A only        -> /dev/video0
sudo scripts/switch_cam_overlay.sh cam1    # cam C only        -> /dev/video0
sudo reboot
```

Only the camera overlay entry on the `OVERLAYS` line of
`/boot/extlinux/extlinux.conf` is rewritten; the 40-pin header overlay is left
alone. A `.imx296mono.bak` copy of extlinux.conf is made each switch.

## 3. Verify the camera streams

After reboot:

```bash
v4l2-ctl -d /dev/video0 --list-formats-ext     # expect: Y10 10-bit Greyscale
bash develop/verify_mono.sh /dev/video0        # RESULT: PASS == streaming
```

## 4. Capture and preview

| Task                                 | Command                                              |
|--------------------------------------|------------------------------------------------------|
| One raw frame (.raw/.pgm/.png)       | `DEVICE=/dev/video0 scripts/camera_control_mono.sh capture cam0` |
| Live preview window                  | `DEVICE=/dev/video0 scripts/camera_control_mono.sh preview`      |

Tunables (environment): `EXPOSURE` (1..1001), `GAIN` (1..201),
`FRAME_RATE` (tegracam units), `PIXEL_FORMAT=auto|Y10|RG10`.

## 5. Troubleshooting

- **No `Y10` format listed:** the patched `tegra-camera.ko` did not take effect.
  Re-run `install_binary.sh`, `sudo depmod -a`, reboot.
- **Black / 0-byte capture (VI timeout):** wrong CSI port for the chosen overlay
  (cam0 = cam A, cam1 = cam C) or a bad cable; run `develop/verify_mono.sh`.
- **Wrong kernel:** both modules require `5.15.148-tegra`.

## 6. Rollback

```bash
scripts/rollback_y10.sh /opt/imx296-mono-backup-YYYYmmddHHMMSS
sudo reboot
```
