#!/bin/bash
# IMX296 color source package installer.
# Installs the prebuilt artifacts from build/ (kernel module + three overlays).
# To rebuild from source instead, see README.md ("Rebuilding").

set -euo pipefail

PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
KVER="$(uname -r)"
MODULE_DIR="/lib/modules/${KVER}/kernel/drivers/media/i2c"
OVERLAYS=(
    tegra234-p3767-camera-p3768-imx296-cam0.dtbo
    tegra234-p3767-camera-p3768-imx296-cam1.dtbo
    tegra234-p3767-camera-p3768-imx296-dual.dtbo
)

echo "=========================================="
echo " IMX296 Color Source Package — Install"
echo "=========================================="
echo "Kernel: ${KVER}"

if [ "$KVER" != "5.15.148-tegra" ]; then
    echo "WARNING: prebuilt module targets 5.15.148-tegra. Rebuild from source"
    echo "for other kernels (see README.md)."
    read -r -p "Continue installing prebuilt anyway? (y/N): " r; [[ "$r" =~ ^[Yy] ]] || exit 1
fi

[ -f "${PKG_DIR}/build/imx296.ko" ] || { echo "ERROR: missing build/imx296.ko"; exit 1; }

echo "Installing kernel module..."
sudo install -D -m 0644 "${PKG_DIR}/build/imx296.ko" "${MODULE_DIR}/imx296.ko"
sudo depmod -a

echo "Installing overlays..."
for o in "${OVERLAYS[@]}"; do
    sudo install -m 0644 "${PKG_DIR}/build/${o}" "/boot/${o}"
    echo "  /boot/${o}"
done

echo ""
echo "Done. Select a configuration and reboot:"
echo "  sudo ${PKG_DIR}/scripts/switch_cam_overlay.sh dual   # dual | cam0 | cam1"
echo "  ${PKG_DIR}/scripts/install_isp.sh                    # color tuning"
echo "  sudo reboot"
