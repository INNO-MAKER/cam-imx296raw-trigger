# IMX296 Color Source Package (working) — 20260615

Source + prebuilt artifacts for IMX296 color camera support on NVIDIA Jetson
Orin Nano/NX, L4T r36.4.4 / JetPack 6, kernel `5.15.148-tegra` (T234).

## Contents

```
source/imx296.c             Kernel sensor driver source
overlay/                    Device-tree overlay sources (.dts):
    ...-imx296-cam0.dts       cam0 only  (CSI cam A, serial_b)
    ...-imx296-cam1.dts       cam1 only  (CSI cam C, serial_c)
    ...-imx296-dual.dts       both cameras
build/                      Prebuilt outputs:
    imx296.ko                 compiled module (5.15.148-tegra)
    *.dtbo                    compiled overlays (hardware-verified)
    *.pp.dts                  preprocessed overlay sources
isp/  isp_source/           Argus ISP color override (camera_overrides.isp)
install_source.sh           Installs the prebuilt build/ artifacts
scripts/                    Preview / control / ISP / overlay-switch helpers
develop/                    On-device verification helper
```

All three overlays (cam0, cam1, dual) were verified on hardware: each captures
a real 1456x1088 RG10 frame.

## Quick install (prebuilt)

```bash
./install_source.sh
sudo scripts/switch_cam_overlay.sh dual   # dual | cam0 | cam1
scripts/install_isp.sh
sudo reboot
scripts/preview_argus.sh            # continuous; Ctrl+C to stop
```

`preview_argus.sh [duration_seconds]` (`0`/omitted = continuous); choose the
camera with `SENSOR_ID=0|1`. Grayscale preview for a mono module:
`scripts/preview_argus_mono.sh`.

## Rebuilding

### Driver (`source/imx296.c`)
Build against the L4T r36.4.4 `nvidia-oot` tree:

```bash
# in the nvidia-oot source tree (kernel 5.15.148-tegra headers configured):
cp source/imx296.c drivers/media/i2c/imx296.c
make modules        # produces drivers/media/i2c/imx296.ko
```

### Overlays (`overlay/*.dts`)
Preprocess with the platform/kernel dt-bindings include paths, then compile:

```bash
INC1=<L4T>/hardware/nvidia/t23x/nv-public/include/platforms
INC2=<L4T>/hardware/nvidia/t23x/nv-public/include/kernel
cpp -nostdinc -I "$INC1" -I "$INC2" -undef -x assembler-with-cpp \
    overlay/tegra234-p3767-camera-p3768-imx296-cam0.dts > cam0.pp.dts
dtc -@ -I dts -O dtb -o cam0.dtbo cam0.pp.dts
```

The `build/*.pp.dts` files are the exact preprocessed inputs used to produce the
shipped `build/*.dtbo`.

## Notes

- The ISP override is experimental tuning (warm/yellow-cast reduction); validate
  image quality before shipping. It only affects the Argus path.
- Mono/grayscale workflows use the raw V4L2 path and do not use the ISP override.
