#!/bin/bash
# IMX296 mono (Y10) binary installer.
# Installs imx296.ko + the Y10-patched tegra-camera.ko and copies all three
# overlays (cam0 / cam1 / dual) into /boot. It does NOT modify the bootloader
# config (extlinux.conf) — after install, select and enable the camera with
# the NVIDIA Jetson-IO menu. A rollback copy is saved under /opt.
set -euo pipefail

PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
KVER="$(uname -r)"
I2C_MODULE_DIR="/lib/modules/${KVER}/kernel/drivers/media/i2c"
TEGRA_CAMERA_MODULE="/lib/modules/${KVER}/updates/drivers/media/platform/tegra/camera/tegra-camera.ko"
OVERLAYS=(
    tegra234-p3767-camera-p3768-imx296mono-cam0.dtbo
    tegra234-p3767-camera-p3768-imx296mono-cam1.dtbo
    tegra234-p3767-camera-p3768-imx296mono-dual.dtbo
)

echo "=========================================="
echo " IMX296 Mono (Y10) Binary Package — Install"
echo "=========================================="
echo "Kernel: ${KVER}"

if [ "$KVER" != "5.15.148-tegra" ]; then
    echo "ERROR: this binary targets 5.15.148-tegra only." >&2
    exit 1
fi

for f in "${PKG_DIR}/binary/imx296.ko" "${PKG_DIR}/binary/tegra-camera.ko"; do
    [ -f "$f" ] || { echo "ERROR: missing $f" >&2; exit 1; }
done
[ -f "${TEGRA_CAMERA_MODULE}" ] || { echo "ERROR: installed tegra-camera.ko not found: ${TEGRA_CAMERA_MODULE}" >&2; exit 1; }

# Timestamped backup of modules + overlays.
# (extlinux.conf is never touched by this installer, so it is not backed up.)
TS="$(date +%Y%m%d%H%M%S)"
BACKUP_DIR="/opt/imx296-mono-backup-${TS}"
sudo mkdir -p "$BACKUP_DIR"
[ -f "${I2C_MODULE_DIR}/imx296.ko" ] && sudo cp -a "${I2C_MODULE_DIR}/imx296.ko" "${BACKUP_DIR}/imx296.ko"
sudo cp -a "${TEGRA_CAMERA_MODULE}" "${BACKUP_DIR}/tegra-camera.ko"
sudo find /boot -maxdepth 1 -type f -name '*imx296*.dtbo' -exec cp -a {} "$BACKUP_DIR"/ \; 2>/dev/null || true
echo "Rollback backup: ${BACKUP_DIR}"

echo "Installing kernel modules..."
sudo install -D -m 0644 "${PKG_DIR}/binary/imx296.ko" "${I2C_MODULE_DIR}/imx296.ko"
sudo install -D -m 0644 "${PKG_DIR}/binary/tegra-camera.ko" "${TEGRA_CAMERA_MODULE}"
sudo depmod -a

echo "Copying overlays to /boot..."
for o in "${OVERLAYS[@]}"; do
    sudo install -m 0644 "${PKG_DIR}/overlays/${o}" "/boot/${o}"
    echo "  /boot/${o}"
done

cat <<EOF

Done. The kernel modules and overlays are in place.

This installer does NOT edit the bootloader config. Select and enable the
camera with the NVIDIA Jetson-IO menu:

  sudo /opt/nvidia/jetson-io/jetson-io.py
    -> Configure Jetson 24pin CSI Connector
    -> choose the IMX296 mono entry (dual or single-cam)
    -> Save and reboot

After rebooting, verify (Y10 grayscale):
  v4l2-ctl -d /dev/video0 --list-formats-ext
  bash ${PKG_DIR}/develop/verify_mono.sh /dev/video0

Rollback if needed:
  ${PKG_DIR}/scripts/rollback_y10.sh ${BACKUP_DIR}
EOF
