#!/bin/bash
# IMX296 color binary installer for Jetson Orin Nano/NX, L4T r36.4.4
# (kernel 5.15.148-tegra). Installs the kernel module and copies all three
# camera overlays (cam0 / cam1 / dual) into /boot. It does NOT modify the
# bootloader config (extlinux.conf) — after install, select and enable the
# camera with the NVIDIA Jetson-IO menu.
# ISP color tuning is installed separately via scripts/install_isp.sh.

set -euo pipefail

PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
KVER="$(uname -r)"
MODULE_DIR="/lib/modules/${KVER}/kernel/drivers/media/i2c"
OVERLAYS=(
    tegra234-p3767-camera-p3768-imx296-cam0.dtbo
    tegra234-p3767-camera-p3768-imx296-cam1.dtbo
    tegra234-p3767-camera-p3768-imx296-dual.dtbo
)

echo "=========================================="
echo " IMX296 Color Binary Installation"
echo "=========================================="
echo "Kernel: ${KVER}"

if [ "$KVER" != "5.15.148-tegra" ]; then
    echo "WARNING: this binary was built for kernel 5.15.148-tegra."
    read -r -p "Continue anyway? (y/N): " r; [[ "$r" =~ ^[Yy] ]] || exit 1
fi

[ -f "${PKG_DIR}/binary/imx296.ko" ] || { echo "ERROR: missing binary/imx296.ko"; exit 1; }
for o in "${OVERLAYS[@]}"; do
    [ -f "${PKG_DIR}/overlays/${o}" ] || { echo "ERROR: missing overlays/${o}"; exit 1; }
done

# Timestamped rollback backup of the current module + any installed overlays.
# (extlinux.conf is never touched by this installer, so it is not backed up.)
TS="$(date +%Y%m%d%H%M%S)"
BACKUP_DIR="/opt/imx296-color-backup-${TS}"
sudo mkdir -p "$BACKUP_DIR"
[ -f "${MODULE_DIR}/imx296.ko" ] && sudo cp -a "${MODULE_DIR}/imx296.ko" "${BACKUP_DIR}/imx296.ko"
sudo find /boot -maxdepth 1 -type f -name '*imx296*.dtbo' -exec cp -a {} "$BACKUP_DIR"/ \; 2>/dev/null || true
echo "Rollback backup: ${BACKUP_DIR}"

echo "Installing kernel module..."
sudo install -D -m 0644 "${PKG_DIR}/binary/imx296.ko" "${MODULE_DIR}/imx296.ko"
sudo depmod -a

echo "Copying device-tree overlays (cam0 / cam1 / dual) to /boot..."
for o in "${OVERLAYS[@]}"; do
    sudo install -m 0644 "${PKG_DIR}/overlays/${o}" "/boot/${o}"
    echo "  /boot/${o}"
done

cat <<EOF

Installation completed. The kernel module and overlays are in place.

This installer does NOT edit the bootloader config. Select and enable the
camera with the NVIDIA Jetson-IO menu:

  sudo /opt/nvidia/jetson-io/jetson-io.py
    -> Configure Jetson 24pin CSI Connector
    -> choose "Camera IMX296-C and IMX296-C" (dual), or the single-cam entry
    -> Save and reboot

For correct color in the Argus preview, also install the ISP tuning:
  ${PKG_DIR}/scripts/install_isp.sh

After rebooting, preview:
  ${PKG_DIR}/scripts/preview_argus.sh

Rollback if needed (kernel module + overlays):
  ${BACKUP_DIR}
EOF
