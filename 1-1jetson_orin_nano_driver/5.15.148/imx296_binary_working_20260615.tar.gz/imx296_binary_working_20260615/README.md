# IMX296 Color Binary Package (working) — 20260615

Prebuilt IMX296 color camera support for NVIDIA Jetson Orin Nano/NX,
L4T r36.4.4 / JetPack 6, kernel `5.15.148-tegra` (T234).

This package contains the kernel module, three device-tree overlays
(cam0 / cam1 / dual), and an experimental Argus ISP color override.

## Contents

```
binary/imx296.ko            Kernel sensor driver (release build, stripped)
overlays/                   Device-tree overlays:
    ...-imx296-cam0.dtbo      cam0 only  (CSI cam A)
    ...-imx296-cam1.dtbo      cam1 only  (CSI cam C)
    ...-imx296-dual.dtbo      both cameras
isp/camera_overrides.isp    Experimental Argus ISP color tuning
install_binary.sh           Installs module + all three overlays
scripts/                    Preview / control / ISP helpers
develop/                    On-device verification helper
```

Both single-camera overlays (cam0, cam1) and the dual overlay have been
verified on hardware (frame capture confirmed) at 1456x1088 RG10.

## Install

```bash
./install_binary.sh         # module + overlays (copied into /boot)
scripts/install_isp.sh      # color tuning (recommended)
```

Then select the camera with the NVIDIA Jetson-IO menu and reboot:

```bash
sudo /opt/nvidia/jetson-io/jetson-io.py
  -> Configure Jetson 24pin CSI Connector
  -> "Camera IMX296-C and IMX296-C" (dual), or the single-cam entry
     (single = cam0 / cam1)
  -> Save and reboot
```

## Preview

Smooth Argus live preview (auto-exposure / auto-gain, GPU display):

```bash
scripts/preview_argus.sh             # continuous; Ctrl+C to stop
scripts/preview_argus.sh 10          # stop after 10 s
SENSOR_ID=1 scripts/preview_argus.sh # cam1 (dual overlay)
```

The positional argument is `duration_seconds` (`0`/omitted = continuous);
choose the camera with the `SENSOR_ID` env var.

Grayscale preview for a mono module: `scripts/preview_argus_mono.sh`
Manual exposure/gain (Argus): `scripts/camera_control_color.sh`
Raw V4L2 capture (no ISP):     `scripts/camera_control_mono.sh`

## Notes

- Install the ISP override (`scripts/install_isp.sh`) for correct color;
  without it the Argus preview can look warm/yellow. The ISP override is
  experimental — validate image quality before shipping to customers.
- The kernel module is built for `5.15.148-tegra` only.
- To roll the ISP override back: `scripts/rollback_isp.sh`.
- Change the booted camera config any time by re-running
  `sudo /opt/nvidia/jetson-io/jetson-io.py`, picking another entry, and rebooting.
