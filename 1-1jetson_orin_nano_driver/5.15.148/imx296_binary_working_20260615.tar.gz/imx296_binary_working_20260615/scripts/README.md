# scripts/

| Script                  | Purpose                                                        |
|-------------------------|----------------------------------------------------------------|
| `preview_argus.sh`      | Color live preview via Argus (auto AE/AGC, GPU sink). Best UX. |
| `preview_argus_mono.sh` | Grayscale live preview via Argus (forces GRAY8; for a mono module on this color/RG10 driver). |
| `camera_control_color.sh` | Color Argus preview with manual exposure/gain prompts.       |
| `camera_control_mono.sh`  | Raw V4L2 capture (bypasses Argus/ISP); `capture` or `preview`. |
| `install_isp.sh`        | Install Argus ISP color override; restarts nvargus-daemon.      |
| `rollback_isp.sh`       | Restore the previous ISP override (or remove the installed one).|

Select the camera (cam0 / cam1 / dual) with the NVIDIA Jetson-IO menu:
`sudo /opt/nvidia/jetson-io/jetson-io.py` -> Configure Jetson 24pin CSI
Connector -> pick the IMX296 dual or single-cam entry -> Save and reboot.

Recommended first run:

```bash
./install_isp.sh
sudo reboot
# after reboot (continuous preview; Ctrl+C to stop):
./preview_argus.sh
# stop after N seconds, or select cam1 on a dual overlay:
./preview_argus.sh 10
SENSOR_ID=1 ./preview_argus.sh
```

`preview_argus.sh [duration_seconds]` — `0`/omitted = continuous. Pick the
camera with the `SENSOR_ID` env var (`0`=cam0 default, `1`=cam1 on a dual
overlay), not a positional argument.

For headless / automation use, an optional helper makes the same selection
safely from the command line. It edits only the DEFAULT boot label, drops
empty/duplicate tokens, and can never produce a malformed (stray-comma)
OVERLAYS line:

```bash
sudo ./configure_extlinux_overlay.sh cam0|cam1|dual   # then reboot
```

Use either this **or** `jetson-io.py`, not both (Jetson-IO may overwrite a
manual edit).
