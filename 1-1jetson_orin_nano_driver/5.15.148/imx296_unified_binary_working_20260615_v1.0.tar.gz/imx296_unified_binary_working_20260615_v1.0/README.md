# IMX296 Unified Binary Package (working) — 20260615

Prebuilt driver for **both color and mono** IMX296 on NVIDIA Jetson Orin
Nano/NX, L4T r36.4.4 / JetPack 6, **kernel `5.15.148-tegra`** (T234).

- **Color** — IMX296LQ, Bayer `RG10`, Argus/ISP path.
- **Mono**  — IMX296LR, grayscale `Y10`, raw V4L2 path (no ISP).

`imx296.ko` auto-detects color vs mono from the chip; `tegra-camera.ko` is the
Y10-patched VI module (the patch is additive — color and other cameras are
unaffected). You pick color or mono by enabling one overlay.

## Contents

```
binary/imx296.ko         sensor driver (auto-detects color/mono)
binary/tegra-camera.ko   VI module, Y10-patched (color-compatible)
overlays/                tegra234-p3767-camera-p3768-imx296-{cam0,cam1,dual}.dtbo      (color)
                         tegra234-p3767-camera-p3768-imx296mono-{cam0,cam1,dual}.dtbo  (mono)
isp/                     Argus color ISP override (color only)
install_binary.sh        Installs both modules + ALL overlays + ISP
scripts/  develop/       Preview / control / verification helpers
```

## Install

```bash
./install_binary.sh
```
Installs both modules + all color & mono overlays. It does **not** edit
`extlinux.conf`. Prebuilt modules only load on **`5.15.148-tegra`**; for another
kernel use the source package (it rebuilds for the running kernel).

### Then choose color OR mono = enable one overlay
`-n` takes `<header-num>=<name>`; on Orin Nano **header 2 = the 24pin CSI
Connector** (header 1 is the 40pin GPIO header). Run `-l` first to confirm.

```bash
sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -l    # list headers + exact names

# --- COLOR (RG10) ---
sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX296-C Cam0'           # CAM0 only
sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX296-C Cam1'           # CAM1 only
sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX296-C and IMX296-C'   # both

# --- MONO (Y10) ---
sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX296LLR-Mono Y10 Cam0'                          # CAM0 only
sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX296LLR-Mono Y10 Cam1'                          # CAM1 only
sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX296LLR-Mono Y10 and IMX296LLR-Mono Y10'        # both

sudo reboot   # enable only ONE of the above, then reboot
```
(cam0 = CSI cam A / serial_b; cam1 = CSI cam C / serial_c.)
Or interactively: `sudo /opt/nvidia/jetson-io/jetson-io.py`.

> **Never hand-edit `extlinux.conf`** — a label without an `FDT` line silently
> ignores `OVERLAYS`. jetson-io / config-by-hardware write a proper label.

### Preview after reboot
```bash
scripts/preview_argus.sh                 # color
scripts/camera_control_mono.sh preview   # mono (raw V4L2 Y10)
```
