#!/bin/bash
# IMX296 Binary Driver Installation Script

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACKAGE_DIR="$(dirname "$SCRIPT_DIR")"

echo "=========================================="
echo "IMX296 Binary Driver Installation"
echo "=========================================="
echo ""

KERNEL_VERSION=$(uname -r)
echo "Current kernel version: $KERNEL_VERSION"

if [ "$KERNEL_VERSION" != "5.15.148-tegra" ]; then
    echo "WARNING: This binary is for kernel 5.15.148-tegra"
    read -p "Continue? (y/N): " -n 1 -r
    echo
    [[ ! $REPLY =~ ^[Yy]$ ]] && exit 1
fi

echo "Installing driver module..."
sudo cp "$PACKAGE_DIR/binary/imx296.ko" /lib/modules/$KERNEL_VERSION/kernel/drivers/media/i2c/
sudo depmod -a

echo "Installing device tree overlay..."
sudo cp "$PACKAGE_DIR/binary/tegra234-p3767-camera-p3768-imx296mono-imx296mono.dtbo" /boot/

echo "Configuring boot settings..."
if ! grep -q "tegra234-p3767-camera-p3768-imx296mono-imx296mono" /boot/extlinux/extlinux.conf; then
    sudo sed -i '/FDT \/boot\/dtb\/kernel_tegra234-p3767-0003-p3768-0000-a0.dtb/a\      OVERLAYS \/boot\/tegra234-p3767-camera-p3768-imx296mono-imx296mono.dtbo' /boot/extlinux/extlinux.conf
fi

echo ""
echo "Installation completed! Please reboot: sudo reboot"
