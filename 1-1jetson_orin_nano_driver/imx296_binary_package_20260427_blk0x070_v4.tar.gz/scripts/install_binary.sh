#!/bin/bash
# IMX296 Binary Driver Installation Script

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACKAGE_DIR="$(dirname "$SCRIPT_DIR")"

echo "=========================================="
echo "IMX296 Binary Driver Installation"
echo "=========================================="
echo ""

KERNEL_VERSION=$(uname -r)
echo "Current kernel version: $KERNEL_VERSION"

if [ "$KERNEL_VERSION" != "5.15.148-tegra" ]; then
    echo "WARNING: This binary is for kernel 5.15.148-tegra"
    read -p "Continue? (y/N): " -n 1 -r
    echo
    [[ ! $REPLY =~ ^[Yy]$ ]] && exit 1
fi

echo "Installing driver module..."
sudo cp "$PACKAGE_DIR/binary/imx296.ko" /lib/modules/$KERNEL_VERSION/kernel/drivers/media/i2c/
sudo depmod -a

echo "Installing device tree overlays..."
sudo cp "$PACKAGE_DIR/binary/"*.dtbo /boot/

echo ""
echo "=========================================="
echo "Installation completed!"
echo "=========================================="
echo ""
echo "Next steps:"
echo "1. Configure CSI camera overlay using jetson-io:"
echo "   sudo /opt/nvidia/jetson-io/jetson-io.py"
echo ""
echo "   Available overlays:"
echo "   - tegra234-p3767-camera-p3768-imx296-imx296 (Color dual)"
echo "   - tegra234-p3767-camera-p3768-imx219-imx296 (IMX219 + IMX296)"
echo "   - tegra234-p3767-camera-p3768-imx477-imx296 (IMX477 + IMX296)"
echo "   - tegra234-p3767-camera-p3768-imx296mono-imx296mono (Mono dual)"
echo "   - tegra234-p3767-camera-p3768-imx296mono-single-csi0 (Mono single)"
echo ""
echo "2. Reboot: sudo reboot"
echo ""
