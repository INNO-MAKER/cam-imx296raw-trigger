#!/bin/bash
# IMX296 Color Camera Preview
# Uses Argus auto-exposure / auto-gain. Picks a video sink that matches
# the environment: nv3dsink under X, nvdrmvideosink only when truly headless.

echo "=== IMX296 Color Camera Preview ==="
echo ""

# Get sensor ID
while true; do
    read -p "Enter sensor ID (0 or 1, default 0): " sensor_id
    sensor_id=${sensor_id:-0}
    if [[ "$sensor_id" =~ ^[0-1]$ ]]; then
        break
    else
        echo "Invalid input. Please enter 0 or 1"
    fi
done

# If no DISPLAY (e.g. SSH session) but an X server is running locally,
# attach to it. Otherwise fall back to direct DRM.
SINK="nv3dsink"
if [ -z "$DISPLAY" ] && [ -z "$WAYLAND_DISPLAY" ]; then
    if pgrep -x Xorg >/dev/null 2>&1 && [ -S /tmp/.X11-unix/X0 ]; then
        export DISPLAY=:0
        for x in \
            "/run/user/$(id -u)/gdm/Xauthority" \
            "/run/user/$(id -u)/Xauthority" \
            "$HOME/.Xauthority"; do
            if [ -r "$x" ]; then export XAUTHORITY="$x"; break; fi
        done
    else
        SINK="nvdrmvideosink"
    fi
fi

echo ""
echo "Starting color camera (sensor-id=${sensor_id}, AE/AGC on, sink=${SINK})..."
echo "Press Ctrl+C to stop."
echo ""

gst-launch-1.0 nvarguscamerasrc sensor-id=${sensor_id} \
  ! 'video/x-raw(memory:NVMM), width=1456, height=1088, format=NV12' \
  ! ${SINK}

echo ""
echo "Video stream stopped."
