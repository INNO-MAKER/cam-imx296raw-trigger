#!/bin/bash
# IMX296 Binary Driver Installation Script (English Version)

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACKAGE_DIR="$(dirname "$SCRIPT_DIR")"

echo "=========================================="
echo "IMX296 Binary Driver Installation"
echo "=========================================="
echo ""

KERNEL_VERSION=$(uname -r)
echo "Current kernel version: $KERNEL_VERSION"

if [ "$KERNEL_VERSION" != "5.15.148-tegra" ]; then
    echo "WARNING: This binary is compiled for kernel 5.15.148-tegra"
    echo "Your kernel version is $KERNEL_VERSION"
    echo "The driver may not work. Consider using the source package instead."
    read -p "Continue anyway? (y/N): " -n 1 -r
    echo
    [[ ! $REPLY =~ ^[Yy]$ ]] && exit 1
fi

echo ""
echo "Step 1: Installing driver module..."
sudo cp "$PACKAGE_DIR/binary/imx296.ko" /lib/modules/$KERNEL_VERSION/kernel/drivers/media/i2c/
sudo depmod -a
echo "  Driver module installed"

echo ""
echo "Step 2: Installing device tree overlay..."
sudo cp "$PACKAGE_DIR/binary/tegra234-p3767-camera-p3768-imx296mono-imx296mono.dtbo" /boot/
echo "  Device tree overlay installed"

echo ""
echo "Step 3: Configuring boot settings..."
if ! grep -q "tegra234-p3767-camera-p3768-imx296mono-imx296mono" /boot/extlinux/extlinux.conf; then
    sudo sed -i '/FDT \/boot\/dtb\/kernel_tegra234-p3767-0003-p3768-0000-a0.dtb/a\      OVERLAYS \/boot\/tegra234-p3767-camera-p3768-imx296mono-imx296mono.dtbo' /boot/extlinux/extlinux.conf
    echo "  Boot configuration updated"
else
    echo "  Boot configuration already contains overlay entry"
fi

echo ""
echo "=========================================="
echo "Installation completed successfully!"
echo "=========================================="
echo ""
echo "Next steps:"
echo "  1. Reboot the system: sudo reboot"
echo "  2. After reboot, verify camera detection: ls /dev/video*"
echo "  3. Test mono camera: cd scripts && ./camera_control.sh"
echo "  4. Test color camera: cd scripts && ./camera_control_color.sh"
echo ""
echo "Driver features:"
echo "  - Auto-detects IMX296 Mono and Color sensors"
echo "  - Mono sensor: Black level 0x070 (reduces column FPN by 96%)"
echo "  - Color sensor: Black level 0x032 (standard value)"
echo ""
