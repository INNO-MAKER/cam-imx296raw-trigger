#!/bin/bash
# IMX296 Mono Camera Control Script
# Allows manual adjustment of exposure and gain

echo "=== IMX296 Mono Camera Control ==="
echo ""
echo "Parameter ranges:"
echo "  Exposure time: 10000 - 1000000 microseconds (0.01ms - 1000ms)"
echo "  Gain: 1 - 16 (1x - 16x amplification)"
echo ""
echo "Recommended starting values:"
echo "  - Test 4: exposure=200000 (200ms), gain=4"
echo "  - Test 5: exposure=500000 (500ms), gain=8"
echo ""

# Get exposure time
while true; do
    read -p "Enter exposure time in microseconds (e.g., 200000): " exposure
    if [[ "$exposure" =~ ^[0-9]+$ ]] && [ "$exposure" -ge 10000 ] && [ "$exposure" -le 1000000 ]; then
        break
    else
        echo "Invalid input. Please enter a number between 10000 and 1000000"
    fi
done

# Get gain value
while true; do
    read -p "Enter gain value (e.g., 4): " gain
    if [[ "$gain" =~ ^[0-9]+$ ]] && [ "$gain" -ge 1 ] && [ "$gain" -le 16 ]; then
        break
    else
        echo "Invalid input. Please enter a number between 1 and 16"
    fi
done

echo ""
echo "Starting camera with:"
echo "  Exposure: ${exposure} microseconds ($(echo "scale=2; $exposure/1000" | bc)ms)"
echo "  Gain: ${gain}x"
echo ""
echo "Press Ctrl+C to stop the video stream"
echo ""

# Launch GStreamer with specified parameters
gst-launch-1.0 nvarguscamerasrc sensor-id=0 \
  exposuretimerange="${exposure} ${exposure}" \
  gainrange="${gain} ${gain}" \
  ! 'video/x-raw(memory:NVMM), width=1456, height=1088, format=NV12' \
  ! nvvidconv \
  ! 'video/x-raw, format=GRAY8' \
  ! videoconvert \
  ! xvimagesink sync=false

echo ""
echo "Video stream stopped."
