# scripts/

| Script                  | Purpose                                                        |
|-------------------------|----------------------------------------------------------------|
| `preview_argus.sh`      | Color live preview via Argus (auto AE/AGC, GPU sink). Best UX. |
| `camera_control_color.sh` | Color Argus preview with manual exposure/gain prompts.       |
| `camera_control_mono.sh`  | Raw V4L2 capture (bypasses Argus/ISP); `capture` or `preview`. |
| `install_isp.sh`        | Install Argus ISP color override; restarts nvargus-daemon.      |
| `rollback_isp.sh`       | Restore the previous ISP override (or remove the installed one).|
| `switch_cam_overlay.sh` | Select boot overlay: `cam0` \| `cam1` \| `dual` (then reboot).  |

Recommended first run:

```bash
sudo switch_cam_overlay.sh dual
./install_isp.sh
sudo reboot
# after reboot:
./preview_argus.sh 0
```
