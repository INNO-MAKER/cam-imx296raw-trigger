# scripts/

| Script                  | Purpose                                                        |
|-------------------------|----------------------------------------------------------------|
| `preview_argus.sh`      | Color live preview via Argus (auto AE/AGC, GPU sink). Best UX. |
| `preview_argus_mono.sh` | Grayscale live preview via Argus (forces GRAY8; for a mono module on this color/RG10 driver). |
| `camera_control_color.sh` | Color Argus preview with manual exposure/gain prompts.       |
| `camera_control_mono.sh`  | Raw V4L2 capture (bypasses Argus/ISP); `capture` or `preview`. |
| `install_isp.sh`        | Install Argus ISP color override; restarts nvargus-daemon.      |
| `rollback_isp.sh`       | Restore the previous ISP override (or remove the installed one).|
| `switch_cam_overlay.sh` | Select boot overlay: `cam0` \| `cam1` \| `dual` (then reboot).  |

Recommended first run:

```bash
sudo switch_cam_overlay.sh dual
./install_isp.sh
sudo reboot
# after reboot (continuous preview; Ctrl+C to stop):
./preview_argus.sh
# stop after N seconds, or select cam1 on a dual overlay:
./preview_argus.sh 10
SENSOR_ID=1 ./preview_argus.sh
```

`preview_argus.sh [duration_seconds]` — `0`/omitted = continuous. Pick the
camera with the `SENSOR_ID` env var (`0`=cam0 default, `1`=cam1 on a dual
overlay), not a positional argument.
