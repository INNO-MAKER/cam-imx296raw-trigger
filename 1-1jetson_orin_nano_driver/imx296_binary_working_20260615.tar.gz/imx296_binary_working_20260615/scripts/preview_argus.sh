#!/bin/bash
# IMX296 Color Live Preview (Argus / ISP path, auto-exposure + auto-gain).
# Smooth GPU-accelerated preview. Install the ISP override first for correct
# color (scripts/install_isp.sh), otherwise the picture may look warm/yellow.
#
# Usage:  ./preview_argus.sh [sensor-id]
#   sensor-id : 0 (cam0) or 1 (cam1); default 0. Only meaningful with the
#               dual overlay. With a single-cam (cam0/cam1) overlay use 0.

set -u

sensor_id="${1:-}"
if [ -z "$sensor_id" ]; then
    read -r -p "Enter sensor ID (0 or 1, default 0): " sensor_id
    sensor_id=${sensor_id:-0}
fi
[[ "$sensor_id" =~ ^[0-1]$ ]] || { echo "sensor-id must be 0 or 1"; exit 1; }

# Pick a working video sink for the current environment.
SINK="nv3dsink"
if [ -z "${DISPLAY:-}" ] && [ -z "${WAYLAND_DISPLAY:-}" ]; then
    if pgrep -x Xorg >/dev/null 2>&1 && [ -S /tmp/.X11-unix/X0 ]; then
        export DISPLAY=:0
        for x in "/run/user/$(id -u)/gdm/Xauthority" \
                 "/run/user/$(id -u)/Xauthority" \
                 "$HOME/.Xauthority"; do
            [ -r "$x" ] && { export XAUTHORITY="$x"; break; }
        done
    else
        SINK="nvdrmvideosink"   # truly headless: render on the DRM console
    fi
fi

echo "IMX296 color preview: sensor-id=${sensor_id}, AE/AGC on, sink=${SINK}"
echo "Press Ctrl+C to stop."

exec gst-launch-1.0 nvarguscamerasrc sensor-id="${sensor_id}" \
    ! 'video/x-raw(memory:NVMM), width=1456, height=1088, format=NV12' \
    ! "${SINK}"
