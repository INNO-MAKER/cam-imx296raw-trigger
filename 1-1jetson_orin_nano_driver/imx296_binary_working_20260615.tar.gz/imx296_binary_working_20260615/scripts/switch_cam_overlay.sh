#!/bin/bash
# Switch the active IMX296 camera overlay in extlinux (cam0 | cam1 | dual).
# Safe: only rewrites the camera dtbo token on the OVERLAYS line; reboot to apply.
set -euo pipefail

SEL="${1:-}"
case "$SEL" in
    cam0|cam1|dual) ;;
    *) echo "Usage: sudo $0 cam0|cam1|dual"; exit 1 ;;
esac

CONF=/boot/extlinux/extlinux.conf
NEW="/boot/tegra234-p3767-camera-p3768-imx296-${SEL}.dtbo"
[ -f "$NEW" ] || { echo "ERROR: $NEW not found"; exit 1; }

# Replace whatever imx296 camera overlay is currently on the OVERLAYS line.
sudo sed -i -E "s#/boot/tegra234-p3767-camera-p3768-imx296-(imx296|cam0|cam1|dual)\.dtbo#${NEW}#g" "$CONF"

echo "Active camera overlay set to: ${SEL}"
grep -E '^\s*OVERLAYS' "$CONF" | sed 's/^[[:space:]]*//'
echo "Reboot to apply:  sudo reboot"
