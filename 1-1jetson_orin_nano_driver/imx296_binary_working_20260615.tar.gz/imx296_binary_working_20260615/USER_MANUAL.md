# IMX296 Color — User Manual

Target: Jetson Orin Nano/NX, L4T r36.4.4 / JetPack 6, kernel 5.15.148-tegra.
Sensor format: 1456x1088, RG10 (10-bit Bayer), up to ~60 fps.

## 1. Install

```bash
./install_binary.sh
```

Installs `imx296.ko` into the running kernel's module tree and copies the
three overlays into `/boot`.

## 2. Choose a camera configuration

```bash
sudo scripts/switch_cam_overlay.sh dual    # both CSI cameras  -> /dev/video0,1
sudo scripts/switch_cam_overlay.sh cam0    # cam A only        -> /dev/video0
sudo scripts/switch_cam_overlay.sh cam1    # cam C only        -> /dev/video0
sudo reboot
```

The switcher only rewrites the camera overlay entry on the `OVERLAYS` line of
`/boot/extlinux/extlinux.conf`; it does not touch the 40-pin header overlay.

## 3. Install ISP color tuning (recommended)

```bash
scripts/install_isp.sh      # writes /var/nvidia/nvcam/settings/camera_overrides.isp
                            # and restarts nvargus-daemon
```

Roll back with `scripts/rollback_isp.sh`.

## 4. Preview and capture

| Task                                   | Command                                  |
|----------------------------------------|------------------------------------------|
| Live preview (auto AE/AGC, GPU)        | `scripts/preview_argus.sh 0`             |
| Manual exposure/gain preview (Argus)   | `scripts/camera_control_color.sh`        |
| Raw V4L2 frame capture (no ISP)        | `scripts/camera_control_mono.sh capture` |

## 5. Verify the camera streams

After reboot:

```bash
bash develop/verify_cam.sh
```

Reports the active overlay, the bound sensor, and captures one frame with
brightness statistics. `RESULT: PASS` means the sensor is streaming.

## 6. Troubleshooting

- **Black / no preview:** confirm a module is connected to the selected CSI
  port (cam0 = cam A port, cam1 = cam C port); run `develop/verify_cam.sh`.
  A 0-byte capture / VI timeout usually means the wrong port or a bad cable.
- **Warm/yellow color:** install the ISP override (step 3), then restart the
  camera app or `sudo systemctl restart nvargus-daemon`.
- **Wrong kernel:** the module requires `5.15.148-tegra`.
