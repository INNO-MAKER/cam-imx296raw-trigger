#!/bin/bash
# IMX296 color binary installer for Jetson Orin Nano/NX, L4T r36.4.4
# (kernel 5.15.148-tegra). Installs the kernel module and all three camera
# overlays (cam0 / cam1 / dual). ISP color tuning is installed separately
# via scripts/install_isp.sh.

set -euo pipefail

PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
KVER="$(uname -r)"
MODULE_DIR="/lib/modules/${KVER}/kernel/drivers/media/i2c"
OVERLAYS=(
    tegra234-p3767-camera-p3768-imx296-cam0.dtbo
    tegra234-p3767-camera-p3768-imx296-cam1.dtbo
    tegra234-p3767-camera-p3768-imx296-dual.dtbo
)

echo "=========================================="
echo " IMX296 Color Binary Installation"
echo "=========================================="
echo "Kernel: ${KVER}"

if [ "$KVER" != "5.15.148-tegra" ]; then
    echo "WARNING: this binary was built for kernel 5.15.148-tegra."
    read -r -p "Continue anyway? (y/N): " r; [[ "$r" =~ ^[Yy] ]] || exit 1
fi

[ -f "${PKG_DIR}/binary/imx296.ko" ] || { echo "ERROR: missing binary/imx296.ko"; exit 1; }
for o in "${OVERLAYS[@]}"; do
    [ -f "${PKG_DIR}/overlays/${o}" ] || { echo "ERROR: missing overlays/${o}"; exit 1; }
done

echo "Installing kernel module..."
sudo install -D -m 0644 "${PKG_DIR}/binary/imx296.ko" "${MODULE_DIR}/imx296.ko"
sudo depmod -a

echo "Installing device-tree overlays (cam0 / cam1 / dual)..."
for o in "${OVERLAYS[@]}"; do
    sudo install -m 0644 "${PKG_DIR}/overlays/${o}" "/boot/${o}"
    echo "  /boot/${o}"
done

echo ""
echo "Installation completed."
echo ""
echo "Select which camera configuration to boot:"
echo "  sudo ${PKG_DIR}/scripts/switch_cam_overlay.sh dual   # both cameras"
echo "  sudo ${PKG_DIR}/scripts/switch_cam_overlay.sh cam0   # cam0 only"
echo "  sudo ${PKG_DIR}/scripts/switch_cam_overlay.sh cam1   # cam1 only"
echo "  sudo reboot"
echo ""
echo "For correct color in the Argus preview, also install the ISP tuning:"
echo "  ${PKG_DIR}/scripts/install_isp.sh"
echo ""
echo "Then preview:  ${PKG_DIR}/scripts/preview_argus.sh"
