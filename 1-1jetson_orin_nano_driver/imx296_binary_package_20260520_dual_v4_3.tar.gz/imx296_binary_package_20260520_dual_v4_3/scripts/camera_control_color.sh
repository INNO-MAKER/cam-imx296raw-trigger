#!/bin/bash
# IMX296 Color Camera Control Script
# Allows manual adjustment of exposure and gain for color sensors

echo "=== IMX296 Color Camera Control ==="
echo ""
echo "Parameter ranges:"
echo "  Exposure time: 10000 - 1000000 microseconds (10ms - 1000ms)"
echo "  Gain: 1 - 16 (1x - 16x amplification)"
echo ""
echo "Recommended starting values:"
echo "  - Normal indoor: exposure=200000 (200ms), gain=4"
echo "  - Bright outdoor: exposure=50000 (50ms), gain=2"
echo "  - Low light: exposure=500000 (500ms), gain=8"
echo ""

# Get exposure time
while true; do
    read -p "Enter exposure time in microseconds (e.g., 200000): " exposure
    if [[ "$exposure" =~ ^[0-9]+$ ]] && [ "$exposure" -ge 10000 ] && [ "$exposure" -le 1000000 ]; then
        break
    else
        echo "Invalid input. Please enter a number between 10000 and 1000000"
    fi
done

# Get gain value
while true; do
    read -p "Enter gain value (e.g., 4): " gain
    if [[ "$gain" =~ ^[0-9]+$ ]] && [ "$gain" -ge 1 ] && [ "$gain" -le 16 ]; then
        break
    else
        echo "Invalid input. Please enter a number between 1 and 16"
    fi
done

# Get sensor ID
while true; do
    read -p "Enter sensor ID (0 or 1, default 0): " sensor_id
    sensor_id=${sensor_id:-0}
    if [[ "$sensor_id" =~ ^[0-1]$ ]]; then
        break
    else
        echo "Invalid input. Please enter 0 or 1"
    fi
done

echo ""
echo "Starting color camera with:"
echo "  Sensor ID: ${sensor_id}"
echo "  Exposure: ${exposure} microseconds ($(echo "scale=2; $exposure/1000" | bc)ms)"
echo "  Gain: ${gain}x"
echo ""
echo "Press Ctrl+C to stop the video stream"
echo ""

# Launch GStreamer with specified parameters for color output
gst-launch-1.0 nvarguscamerasrc sensor-id=${sensor_id} \
  exposuretimerange="${exposure} ${exposure}" \
  gainrange="${gain} ${gain}" \
  ! 'video/x-raw(memory:NVMM), width=1456, height=1088, format=NV12, framerate=60/1' \
  ! nvvidconv \
  ! 'video/x-raw, format=BGRx' \
  ! videoconvert \
  ! xvimagesink sync=false

echo ""
echo "Video stream stopped."
