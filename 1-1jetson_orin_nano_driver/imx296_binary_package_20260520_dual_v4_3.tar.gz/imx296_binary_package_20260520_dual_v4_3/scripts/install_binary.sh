#!/bin/bash
# IMX296 dual-camera binary installation script for Jetson Orin Nano/NX L4T r36.4.4.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACKAGE_DIR="$(dirname "$SCRIPT_DIR")"
KERNEL_VERSION="$(uname -r)"
MODULE_DIR="/lib/modules/${KERNEL_VERSION}/kernel/drivers/media/i2c"
DTBO_NAME="tegra234-p3767-camera-p3768-imx296-imx296.dtbo"

echo "=========================================="
echo "IMX296 Dual Binary Driver Installation"
echo "=========================================="
echo "Kernel: ${KERNEL_VERSION}"

if [ "$KERNEL_VERSION" != "5.15.148-tegra" ]; then
    echo "WARNING: this binary was built for kernel 5.15.148-tegra."
    read -r -p "Continue anyway? (y/N): " reply
    case "$reply" in
        [Yy]*) ;;
        *) exit 1 ;;
    esac
fi

if [ ! -f "${PACKAGE_DIR}/binary/imx296.ko" ]; then
    echo "ERROR: missing ${PACKAGE_DIR}/binary/imx296.ko" >&2
    exit 1
fi

if [ ! -f "${PACKAGE_DIR}/binary/${DTBO_NAME}" ]; then
    echo "ERROR: missing ${PACKAGE_DIR}/binary/${DTBO_NAME}" >&2
    exit 1
fi

echo "Installing kernel module..."
sudo install -D -m 0644 "${PACKAGE_DIR}/binary/imx296.ko" "${MODULE_DIR}/imx296.ko"
sudo depmod -a

echo "Installing device-tree overlay..."
sudo install -m 0644 "${PACKAGE_DIR}/binary/${DTBO_NAME}" "/boot/${DTBO_NAME}"

echo "Removing stale IMX296 overlays from /boot..."
sudo find /boot -maxdepth 1 -type f -name '*imx296*.dtbo' ! -name "${DTBO_NAME}" -print -delete

echo ""
echo "Installation completed."
echo ""
echo "Final overlay:"
echo "  /boot/${DTBO_NAME}"
echo ""
echo "Configure boot overlay with Jetson-IO or extlinux:"
echo "  sudo /opt/nvidia/jetson-io/jetson-io.py"
echo ""
echo "Jetson-IO overlay display name:"
echo "  Camera IMX296-C and IMX296-C"
echo ""
echo "Reboot after selecting the overlay:"
echo "  sudo reboot"
