#!/bin/bash
# IMX296 Mono Camera Brightness Adjustment Script

echo "=== IMX296 Mono Camera Brightness Adjustment ==="
echo "Each test will show a live video window. Press Ctrl+C to stop and move to next test."
echo ""

# Test 1: Very low exposure
echo "Test 1: Very low exposure (10ms, gain 1x)"
echo "Press Enter to start..."
read
gst-launch-1.0 nvarguscamerasrc sensor-id=0 \
  exposuretimerange="10000 10000" \
  gainrange="1 1" \
  ! 'video/x-raw(memory:NVMM), width=1456, height=1088, format=NV12' \
  ! nvvidconv \
  ! 'video/x-raw, format=GRAY8' \
  ! videoconvert \
  ! xvimagesink sync=false

echo ""

# Test 2: Low exposure
echo "Test 2: Low exposure (50ms, gain 1x)"
echo "Press Enter to start..."
read
gst-launch-1.0 nvarguscamerasrc sensor-id=0 \
  exposuretimerange="50000 50000" \
  gainrange="1 1" \
  ! 'video/x-raw(memory:NVMM), width=1456, height=1088, format=NV12' \
  ! nvvidconv \
  ! 'video/x-raw, format=GRAY8' \
  ! videoconvert \
  ! xvimagesink sync=false

echo ""

# Test 3: Medium exposure
echo "Test 3: Medium exposure (100ms, gain 2x)"
echo "Press Enter to start..."
read
gst-launch-1.0 nvarguscamerasrc sensor-id=0 \
  exposuretimerange="100000 100000" \
  gainrange="2 2" \
  ! 'video/x-raw(memory:NVMM), width=1456, height=1088, format=NV12' \
  ! nvvidconv \
  ! 'video/x-raw, format=GRAY8' \
  ! videoconvert \
  ! xvimagesink sync=false

echo ""

# Test 4: Higher exposure
echo "Test 4: Higher exposure (200ms, gain 4x)"
echo "Press Enter to start..."
read
gst-launch-1.0 nvarguscamerasrc sensor-id=0 \
  exposuretimerange="200000 200000" \
  gainrange="4 4" \
  ! 'video/x-raw(memory:NVMM), width=1456, height=1088, format=NV12' \
  ! nvvidconv \
  ! 'video/x-raw, format=GRAY8' \
  ! videoconvert \
  ! xvimagesink sync=false

echo ""

# Test 5: Very high exposure
echo "Test 5: Very high exposure (500ms, gain 8x)"
echo "Press Enter to start..."
read
gst-launch-1.0 nvarguscamerasrc sensor-id=0 \
  exposuretimerange="500000 500000" \
  gainrange="8 8" \
  ! 'video/x-raw(memory:NVMM), width=1456, height=1088, format=NV12' \
  ! nvvidconv \
  ! 'video/x-raw, format=GRAY8' \
  ! videoconvert \
  ! xvimagesink sync=false

echo ""
echo "=== Testing Complete ==="

echo ""
echo "=== Brightness adjustment tests completed ==="
echo ""
echo "Tips:"
echo "- Lower exposuretimerange values = darker image"
echo "- Lower gainrange values = darker image"
echo "- Adjust these values based on your lighting conditions"
