#!/bin/bash
set -euo pipefail

# IMX296LLR mono V4L2 raw capture helper.
# Captures RAW10 frames and writes raw/preview files for inspection.

WIDTH=${WIDTH:-1456}
HEIGHT=${HEIGHT:-1088}
DEVICE=${DEVICE:-/dev/video0}
OUT_DIR=${OUT_DIR:-.}
MODE=${1:-capture}
EXPOSURE=${EXPOSURE:-800}
GAIN=${GAIN:-100}
FRAME_RATE=${FRAME_RATE:-30000000}
PIXEL_FORMAT=${PIXEL_FORMAT:-auto}

usage() {
    cat <<EOF
Usage:
  $0 capture [output_prefix]
  $0 preview

Environment:
  DEVICE=/dev/video0|/dev/video1
  EXPOSURE=1..1001          V4L2 exposure control units
  GAIN=1..201               V4L2 gain control units
  FRAME_RATE=30000000       30 fps in tegracam units
  PIXEL_FORMAT=auto|Y10|RG10
  OUT_DIR=.                 output directory for capture mode

Examples:
  DEVICE=/dev/video0 EXPOSURE=800 GAIN=100 $0 capture cam0
  DEVICE=/dev/video1 EXPOSURE=800 GAIN=100 $0 preview
EOF
}

if [[ "${MODE}" == "-h" || "${MODE}" == "--help" ]]; then
    usage
    exit 0
fi

command -v v4l2-ctl >/dev/null || { echo "v4l2-ctl not found"; exit 1; }
command -v python3 >/dev/null || { echo "python3 not found"; exit 1; }

mkdir -p "${OUT_DIR}"

detect_pixel_format() {
    if [ "${PIXEL_FORMAT}" != "auto" ]; then
        echo "${PIXEL_FORMAT}"
        return
    fi

    local fmt
    fmt="$(v4l2-ctl -d "${DEVICE}" --get-fmt-video 2>/dev/null | awk -F"'" '/Pixel Format/ {print $2; exit}')"
    case "${fmt}" in
        "Y10 ") echo "Y10" ;;
        "RG10") echo "RG10" ;;
        *) echo "RG10" ;;
    esac
}

set_controls() {
    v4l2-ctl -d "${DEVICE}" \
        --set-ctrl bypass_mode=0 \
        --set-ctrl override_enable=0 \
        --set-ctrl exposure="${EXPOSURE}" \
        --set-ctrl gain="${GAIN}" \
        --set-ctrl frame_rate="${FRAME_RATE}" >/dev/null
}

capture_one() {
    local raw_path=$1
    local pixel_format=$2
    if [ "${pixel_format}" = "Y10" ]; then
        v4l2-ctl -d "${DEVICE}" \
            --set-fmt-video=width="${WIDTH}",height="${HEIGHT}" >/dev/null
    else
        v4l2-ctl -d "${DEVICE}" \
            --set-fmt-video=width="${WIDTH}",height="${HEIGHT}",pixelformat=RG10 >/dev/null
    fi
    v4l2-ctl -d "${DEVICE}" \
        --stream-mmap \
        --stream-count=1 \
        --stream-to="${raw_path}" >/dev/null
}

convert_raw() {
    local raw_path=$1
    local prefix=$2
    WIDTH="${WIDTH}" HEIGHT="${HEIGHT}" RAW_PATH="${raw_path}" PREFIX="${prefix}" python3 - <<'PY'
import os
from pathlib import Path

import numpy as np

w = int(os.environ["WIDTH"])
h = int(os.environ["HEIGHT"])
raw_path = Path(os.environ["RAW_PATH"])
prefix = Path(os.environ["PREFIX"])

data = raw_path.read_bytes()
expected = w * h * 2
if len(data) != expected:
    raise SystemExit(f"Unexpected RAW size: {len(data)} bytes, expected {expected}")

arr = np.frombuffer(data, dtype="<u2").reshape(h, w)

# Jetson VI stores RAW10 in a 16-bit container. Pick the component with the
# useful 10-bit dynamic range, then normalize for display.
lo = arr & 0x03ff
hi = arr >> 6
img10 = lo if np.percentile(lo, 99) >= np.percentile(hi, 99) else hi
p1, p99 = np.percentile(img10, [1, 99])
img8 = np.clip((img10 - p1) * 255.0 / max(p99 - p1, 1), 0, 255).astype(np.uint8)

pgm_path = prefix.with_suffix(".pgm")
pgm_path.write_bytes(b"P5\n%d %d\n255\n" % (w, h) + img8.tobytes())

try:
    import cv2
    png_path = prefix.with_suffix(".png")
    cv2.imwrite(str(png_path), img8)
    print(f"Wrote {png_path}")
except Exception:
    print(f"Wrote {pgm_path}")

print(
    "RAW10 stats:",
    f"min={int(img10.min())}",
    f"max={int(img10.max())}",
    f"mean={float(img10.mean()):.1f}",
    f"p99={float(np.percentile(img10, 99)):.1f}",
)
PY
}

preview_loop() {
    WIDTH="${WIDTH}" HEIGHT="${HEIGHT}" DEVICE="${DEVICE}" EXPOSURE="${EXPOSURE}" GAIN="${GAIN}" FRAME_RATE="${FRAME_RATE}" python3 - <<'PY'
import os
import subprocess
import tempfile
from pathlib import Path

import cv2
import numpy as np

w = int(os.environ["WIDTH"])
h = int(os.environ["HEIGHT"])
device = os.environ["DEVICE"]
exposure = os.environ["EXPOSURE"]
gain = os.environ["GAIN"]
frame_rate = os.environ["FRAME_RATE"]

def run(cmd):
    subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL)

run([
    "v4l2-ctl", "-d", device,
    "--set-ctrl", "bypass_mode=0",
    "--set-ctrl", "override_enable=0",
    "--set-ctrl", f"exposure={exposure}",
    "--set-ctrl", f"gain={gain}",
    "--set-ctrl", f"frame_rate={frame_rate}",
])

with tempfile.TemporaryDirectory(prefix="imx296mono_") as tmp:
    raw = Path(tmp) / "frame.raw"
    while True:
        run([
            "v4l2-ctl", "-d", device,
            f"--set-fmt-video=width={w},height={h}",
            "--stream-mmap", "--stream-count=1", f"--stream-to={raw}",
        ])
        arr = np.frombuffer(raw.read_bytes(), dtype="<u2").reshape(h, w)
        lo = arr & 0x03ff
        hi = arr >> 6
        img10 = lo if np.percentile(lo, 99) >= np.percentile(hi, 99) else hi
        p1, p99 = np.percentile(img10, [1, 99])
        img8 = np.clip((img10 - p1) * 255.0 / max(p99 - p1, 1), 0, 255).astype(np.uint8)
        cv2.imshow(f"IMX296 mono {device}", img8)
        if cv2.waitKey(1) in (27, ord("q")):
            break
cv2.destroyAllWindows()
PY
}

case "${MODE}" in
    capture)
        prefix_name=${2:-"imx296_mono_${DEVICE##*/}"}
        raw_path="${OUT_DIR}/${prefix_name}.raw"
        out_prefix="${OUT_DIR}/${prefix_name}"
        pixel_format="$(detect_pixel_format)"
        echo "Capturing ${DEVICE}: format=${pixel_format}, exposure=${EXPOSURE}, gain=${GAIN}, frame_rate=${FRAME_RATE}"
        set_controls
        capture_one "${raw_path}" "${pixel_format}"
        convert_raw "${raw_path}" "${out_prefix}"
        echo "Wrote ${raw_path}"
        ;;
    preview)
        echo "Previewing ${DEVICE}: exposure=${EXPOSURE}, gain=${GAIN}, frame_rate=${FRAME_RATE}"
        echo "Press q or Esc to exit."
        preview_loop
        ;;
    *)
        usage
        exit 1
        ;;
esac
