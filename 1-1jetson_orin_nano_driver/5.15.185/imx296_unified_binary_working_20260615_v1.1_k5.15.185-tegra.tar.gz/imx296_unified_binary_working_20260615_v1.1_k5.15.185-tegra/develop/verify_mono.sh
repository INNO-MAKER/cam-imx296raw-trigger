#!/bin/bash
# On-device check that the mono (Y10) sensor streams a real frame.
# Captures one V4L2 raw frame and reports brightness stats. PASS if mean > 5.
set -euo pipefail

DEV="${1:-/dev/video0}"
W=1456; H=1088
OUT="/tmp/imx296mono_verify_${DEV##*/}.raw"

command -v v4l2-ctl >/dev/null || { echo "v4l2-ctl not found"; exit 1; }
[ -e "$DEV" ] || { echo "ERROR: $DEV not present (is the overlay installed/booted?)"; exit 1; }

echo "Device: $DEV"
v4l2-ctl -d "$DEV" --list-formats | grep -iE 'Y10|RG10' || true

v4l2-ctl -d "$DEV" \
    --set-ctrl bypass_mode=0 \
    --set-ctrl override_enable=0 \
    --set-ctrl exposure=800 \
    --set-ctrl gain=120 >/dev/null 2>&1 || true

v4l2-ctl -d "$DEV" --set-fmt-video=width=$W,height=$H \
    --stream-mmap --stream-count=1 --stream-to="$OUT" >/dev/null

SZ=$(stat -c%s "$OUT")
echo "Captured: $SZ bytes (expected $((W*H*2)))"
[ "$SZ" -eq $((W*H*2)) ] || { echo "RESULT: FAIL (unexpected frame size / VI timeout)"; exit 1; }

MEAN=$(python3 - "$OUT" "$W" "$H" <<'PY'
import sys, numpy as np
data=open(sys.argv[1],'rb').read(); w=int(sys.argv[2]); h=int(sys.argv[3])
a=np.frombuffer(data,dtype='<u2').reshape(h,w)&0x03ff
print(f"{a.mean():.1f}")
PY
)
echo "Frame mean (10-bit): $MEAN"
awk "BEGIN{exit !($MEAN>5)}" && echo "RESULT: PASS" || { echo "RESULT: FAIL (frame too dark / no signal)"; exit 1; }
