#!/bin/bash
# Verify the currently-booted IMX296 single-camera overlay actually streams.
# Run AFTER rebooting into a cam0/cam1 overlay.
set -uo pipefail

D=/dev/video0
echo "=== Active boot overlay ==="
grep -E 'MENU LABEL Custom|OVERLAYS' /boot/extlinux/extlinux.conf | sed 's/^[[:space:]]*//'
echo
echo "=== Video nodes ==="
ls /dev/video* 2>/dev/null || { echo "NO /dev/video* — overlay/sensor not up"; exit 1; }
echo
echo "=== Sensor bound? (media entity) ==="
media-ctl -d /dev/media0 -p 2>/dev/null | grep -E 'imx296|ENABLED' | head
echo
echo "=== Format ==="
v4l2-ctl -d "$D" --get-fmt-video 2>/dev/null | grep -E 'Width|Pixel'
echo
echo "=== Set controls + capture 1 frame ==="
v4l2-ctl -d "$D" --set-ctrl bypass_mode=0 --set-ctrl override_enable=0 \
    --set-ctrl exposure=500 --set-ctrl gain=120 --set-ctrl frame_rate=30000000 2>/dev/null
RAW=/tmp/verify_${1:-cam}.raw
v4l2-ctl -d "$D" --set-fmt-video=width=1456,height=1088 \
    --stream-mmap --stream-count=1 --stream-to="$RAW" 2>&1
SZ=$(stat -c%s "$RAW" 2>/dev/null || echo 0)
echo "captured: $SZ bytes (expect 3168256)"
if [ "$SZ" -eq 3168256 ]; then
    python3 - "$RAW" <<'PY'
import sys, numpy as np
a = np.frombuffer(open(sys.argv[1],'rb').read(), dtype='<u2').reshape(1088,1456) & 0x3ff
print("RAW10 stats: min=%d max=%d mean=%.1f p99=%.1f nonzero%%=%.1f" % (
    a.min(), a.max(), a.mean(), np.percentile(a,99), 100*(a!=0).mean()))
print("RESULT: PASS — sensor is streaming real data" if a.mean() > 5 else
      "RESULT: FRAME CAME BUT ALL ~0 — check lens/exposure")
PY
else
    echo "RESULT: FAIL — no frame (VI timeout). Overlay or sensor not streaming."
fi
