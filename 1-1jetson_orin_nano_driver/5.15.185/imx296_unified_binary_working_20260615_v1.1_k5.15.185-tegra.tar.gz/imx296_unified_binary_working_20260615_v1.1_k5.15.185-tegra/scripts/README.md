# scripts/

| Script                  | Purpose                                                          |
|-------------------------|------------------------------------------------------------------|
| `camera_control_mono.sh`| Raw V4L2 capture/preview of Y10 grayscale (`capture` \| `preview`). |
| `rollback_y10.sh`       | Restore modules + overlays from an `/opt/imx296-mono-backup-*` dir. |

Mono uses the **raw V4L2 path** (no Argus, no ISP). There is no `install_isp.sh`.

```bash
# capture one frame to .raw/.pgm/.png
DEVICE=/dev/video0 ./camera_control_mono.sh capture cam0_y10
# live preview window (needs OpenCV + display)
DEVICE=/dev/video0 ./camera_control_mono.sh preview
```

For headless / automation use, an optional helper makes the same selection
safely from the command line. It edits only the DEFAULT boot label, drops
empty/duplicate tokens, and can never produce a malformed (stray-comma)
OVERLAYS line:

```bash
sudo ./configure_extlinux_overlay.sh cam0|cam1|dual   # then reboot
```

Use either this **or** `jetson-io.py`, not both (Jetson-IO may overwrite a
manual edit).
