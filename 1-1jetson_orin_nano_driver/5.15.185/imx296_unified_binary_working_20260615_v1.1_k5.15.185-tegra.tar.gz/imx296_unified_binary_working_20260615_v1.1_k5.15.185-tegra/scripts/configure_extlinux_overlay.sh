#!/usr/bin/env bash
# OPTIONAL command-line camera-overlay selector for IMX296 mono (Y10).
#
# This is an alternative to the recommended NVIDIA Jetson-IO menu
#   sudo /opt/nvidia/jetson-io/jetson-io.py
# intended for headless / automation use. The installer does NOT call it.
#
# It rewrites ONLY the OVERLAYS line of the DEFAULT boot label in
# extlinux.conf. The existing list is tokenized; empty/duplicate tokens and
# any previous camera overlay (tegra234-p3767-camera-*.dtbo) are dropped, then
# the chosen overlay is appended. This makes a malformed OVERLAYS line (e.g. a
# stray leading/trailing comma) impossible. Non-camera overlays (such as the
# 40-pin header) are preserved. A timestamped backup is written.
#
# NOTE: editing extlinux.conf directly bypasses Jetson-IO's own state. If you
# later run jetson-io.py it may overwrite this change — pick one method.
set -euo pipefail

SEL="${1:-}"
case "$SEL" in
    cam0|cam1|dual) ;;
    *) echo "Usage: sudo $0 cam0|cam1|dual"; exit 1 ;;
esac

CONF="${CONF:-/boot/extlinux/extlinux.conf}"
OVERLAY="/boot/tegra234-p3767-camera-p3768-imx296mono-${SEL}.dtbo"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP="${CONF}.backup_imx296mono_${STAMP}"

[ -f "$CONF" ]    || { echo "ERROR: extlinux config not found: ${CONF}" >&2; exit 1; }
[ -f "$OVERLAY" ] || { echo "ERROR: overlay not found: ${OVERLAY}" >&2; echo "Run the installer first." >&2; exit 1; }

DEFAULT_LABEL="$(awk '$1 == "DEFAULT" { print $2; exit }' "$CONF")"
[ -n "$DEFAULT_LABEL" ] || DEFAULT_LABEL="primary"

echo "Configuring IMX296 mono camera overlay in ${CONF}"
echo "Default label: ${DEFAULT_LABEL}"
echo "Overlay: ${OVERLAY}"

SUDO=()
if [ "$(id -u)" -ne 0 ] && { [ ! -w "$CONF" ] || [ ! -w "$(dirname "$CONF")" ]; }; then
    SUDO=(sudo)
fi

"${SUDO[@]}" cp "$CONF" "$BACKUP"
echo "Backup: ${BACKUP}"

TMP="$(mktemp)"
awk -v target="$DEFAULT_LABEL" -v overlay="$OVERLAY" '
function emit_overlay_line(line,    indent, rest, n, items, i, out, tok) {
    indent = line; sub(/[^ \t].*$/, "", indent);
    rest = line;   sub(/^[ \t]*OVERLAYS[ \t]*/, "", rest);
    n = split(rest, items, ",");
    out = "";
    for (i = 1; i <= n; i++) {
        tok = items[i];
        gsub(/^[ \t]+|[ \t]+$/, "", tok);
        if (tok == "" || tok == overlay) continue;
        if (tok ~ /\/boot\/tegra234-p3767-camera-.*\.dtbo$/) continue;
        out = out (out == "" ? "" : ",") tok;
    }
    out = out (out == "" ? "" : ",") overlay;
    print indent "OVERLAYS " out;
}
function maybe_insert_overlay() {
    if (in_target && !saw_overlays) print "\tOVERLAYS " overlay;
}
$1 == "LABEL" {
    if (in_target) maybe_insert_overlay();
    in_target = ($2 == target); saw_overlays = 0; print; next;
}
in_target && $1 == "OVERLAYS" { emit_overlay_line($0); saw_overlays = 1; next; }
{ print }
END { if (in_target) maybe_insert_overlay(); }
' "$CONF" > "$TMP"

"${SUDO[@]}" install -m 0644 "$TMP" "$CONF"
rm -f "$TMP"

echo "Updated overlay line:"
awk -v target="$DEFAULT_LABEL" '
$1 == "LABEL" { in_target = ($2 == target) }
in_target && $1 == "OVERLAYS" { print; exit }
' "$CONF"

echo
echo "Alternative: select interactively with NVIDIA Jetson-IO:"
echo "  sudo /opt/nvidia/jetson-io/jetson-io.py"
echo "Reboot is required for the overlay to take effect."
