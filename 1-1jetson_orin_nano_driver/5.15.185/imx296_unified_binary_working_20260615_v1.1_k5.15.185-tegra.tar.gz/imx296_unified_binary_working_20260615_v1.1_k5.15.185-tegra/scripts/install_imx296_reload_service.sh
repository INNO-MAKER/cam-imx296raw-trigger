#!/usr/bin/env bash
# Install imx296-reload.service.
#
# At every boot the service: stops nvargus-daemon, reloads the imx296 kernel
# module (which re-probes / re-powers the sensor), then restarts the daemon.
# This fixes the post-reboot black-screen / "module not initialized" issue
# where argus comes up before the sensor is fully ready (same approach used
# for the IMX585 driver).

set -euo pipefail

SERVICE_FILE="imx296-reload.service"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# Service file may sit in the package root (parent of scripts/) or next to
# this script.
if [ -f "${SCRIPT_DIR}/${SERVICE_FILE}" ]; then
    SERVICE_SRC="${SCRIPT_DIR}/${SERVICE_FILE}"
elif [ -f "${SCRIPT_DIR}/../${SERVICE_FILE}" ]; then
    SERVICE_SRC="${SCRIPT_DIR}/../${SERVICE_FILE}"
else
    echo "ERROR: ${SERVICE_FILE} not found in ${SCRIPT_DIR} or its parent" >&2
    exit 1
fi
SERVICE_DST="/etc/systemd/system/${SERVICE_FILE}"

echo "Installing imx296-reload service..."
echo "Source: ${SERVICE_SRC}"
sudo install -m 0644 "$SERVICE_SRC" "$SERVICE_DST"

echo "Enabling service..."
sudo systemctl daemon-reload
sudo systemctl enable imx296-reload.service

echo ""
echo "Service installed and enabled: ${SERVICE_DST}"
echo ""
echo "At every boot it will:"
echo "  - Stop nvargus-daemon"
echo "  - Reload the imx296 kernel module (re-probe the sensor)"
echo "  - Restart nvargus-daemon"
echo ""
echo "Verify:  systemctl is-enabled imx296-reload.service   # should be 'enabled'"
echo "Test now:  sudo systemctl start imx296-reload.service"
echo "Status:    sudo systemctl status imx296-reload.service"
