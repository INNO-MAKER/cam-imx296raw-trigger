#!/bin/bash
# Install IMX296 camera_overrides.isp and keep a rollback record.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACKAGE_DIR="$(dirname "$SCRIPT_DIR")"
SRC="${PACKAGE_DIR}/isp/camera_overrides.isp"
SETTINGS_DIR="/var/nvidia/nvcam/settings"
DST="${SETTINGS_DIR}/camera_overrides.isp"
BACKUP_DIR="${SETTINGS_DIR}/backup_imx296_isp"
STATE_FILE="${BACKUP_DIR}/last_install_state"
STAMP="$(date +%Y%m%d_%H%M%S)"

if [ ! -f "$SRC" ]; then
    echo "ERROR: ${SRC} not found."
    exit 1
fi

if [ ! -s "$SRC" ]; then
    echo "ERROR: ${SRC} is empty. Refusing to install."
    exit 1
fi

echo "Installing IMX296 ISP override..."
sudo mkdir -p "$SETTINGS_DIR" "$BACKUP_DIR"

if [ -f "$DST" ]; then
    BACKUP_FILE="${BACKUP_DIR}/camera_overrides.isp.${STAMP}.bak"
    sudo cp "$DST" "$BACKUP_FILE"
    printf "backup=%s\n" "$BACKUP_FILE" | sudo tee "$STATE_FILE" >/dev/null
    echo "Backed up existing override to: ${BACKUP_FILE}"
else
    printf "backup=\n" | sudo tee "$STATE_FILE" >/dev/null
    echo "No existing override found. Rollback will remove the installed file."
fi

sudo install -m 0644 "$SRC" "$DST"

echo "Installed: ${DST}"
echo "Restarting nvargus-daemon..."
sudo systemctl restart nvargus-daemon
echo "Done."

