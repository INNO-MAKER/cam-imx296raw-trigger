#!/usr/bin/env bash
# IMX296 UNIFIED binary package installer (prebuilt, kernel 5.15.185-tegra).
#
# ONE package covers both color (IMX296LQ, RG10) and mono (IMX296LR, Y10):
#   binary/imx296.ko        sensor driver (auto-detects color vs mono from the chip)
#   binary/tegra-camera.ko  VI module, Y10-patched (additive; color paths unchanged)
# Installs both modules + ALL overlays (color + mono). You then pick color OR mono
# by enabling one overlay. It does NOT modify the bootloader config — select the
# camera afterward with jetson-io / config-by-hardware.
#
# For a different kernel, use the source package (it rebuilds for the running
# kernel); a prebuilt .ko only loads on the kernel it was built for.
set -euo pipefail

die()  { echo "ERROR: $*" >&2; exit 1; }

PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
KVER="$(uname -r)"
I2C_MODULE_DIR="/lib/modules/${KVER}/kernel/drivers/media/i2c"
TEGRA_CAMERA_MODULE="/lib/modules/${KVER}/updates/drivers/media/platform/tegra/camera/tegra-camera.ko"
OVERLAYS=(
    tegra234-p3767-camera-p3768-imx296-cam0
    tegra234-p3767-camera-p3768-imx296-cam1
    tegra234-p3767-camera-p3768-imx296-dual
    tegra234-p3767-camera-p3768-imx296mono-cam0
    tegra234-p3767-camera-p3768-imx296mono-cam1
    tegra234-p3767-camera-p3768-imx296mono-dual
)

echo "Installing IMX296 unified binary driver (color + mono)"
echo "Kernel: ${KVER}"

EXPECTED_KERNEL="5.15.185-tegra"
if [ "$KVER" != "${EXPECTED_KERNEL}" ]; then
    echo "WARNING: prebuilt modules target ${EXPECTED_KERNEL}; running kernel is ${KVER}."
    echo "         modprobe will reject a vermagic mismatch — use the SOURCE package"
    echo "         (it rebuilds imx296.ko + tegra-camera.ko for the running kernel)."
    read -r -p "Continue installing prebuilt anyway? (y/N): " r; [[ "$r" =~ ^[Yy] ]] || exit 1
fi

[ -f "${PKG_DIR}/binary/imx296.ko" ]       || die "missing binary/imx296.ko"
[ -f "${PKG_DIR}/binary/tegra-camera.ko" ] || die "missing binary/tegra-camera.ko"
for o in "${OVERLAYS[@]}"; do
    [ -f "${PKG_DIR}/overlays/${o}.dtbo" ] || die "missing overlays/${o}.dtbo"
done

# Rollback backup of the currently installed modules.
# (extlinux.conf is never touched by this installer, so it is not backed up.)
TS="$(date +%Y%m%d%H%M%S)"
BACKUP_DIR="/opt/imx296-unified-backup-${TS}"
sudo mkdir -p "$BACKUP_DIR"
[ -f "${I2C_MODULE_DIR}/imx296.ko" ] && sudo cp -a "${I2C_MODULE_DIR}/imx296.ko" "${BACKUP_DIR}/imx296.ko"
[ -f "${TEGRA_CAMERA_MODULE}" ]      && sudo cp -a "${TEGRA_CAMERA_MODULE}"      "${BACKUP_DIR}/tegra-camera.ko"
echo "Rollback backup: ${BACKUP_DIR}"

echo "=== Installing modules + overlays ==="
sudo install -D -m 0644 "${PKG_DIR}/binary/imx296.ko"       "${I2C_MODULE_DIR}/imx296.ko"
sudo install -D -m 0644 "${PKG_DIR}/binary/tegra-camera.ko" "${TEGRA_CAMERA_MODULE}"
sudo depmod -a
for o in "${OVERLAYS[@]}"; do
    sudo install -m 0644 "${PKG_DIR}/overlays/${o}.dtbo" "/boot/${o}.dtbo"
    echo "  /boot/${o}.dtbo"
done

# Color starter ISP (harmless for mono, which uses the raw V4L2 path).
if [ -x "${PKG_DIR}/scripts/install_isp.sh" ]; then
    "${PKG_DIR}/scripts/install_isp.sh" || echo "WARNING: ISP install failed (non-fatal)"
fi

sudo mkdir -p /etc/modules-load.d
echo imx296 | sudo tee /etc/modules-load.d/imx296.conf >/dev/null

# Install imx296-reload.service (fixes post-reboot black screen: at every boot
# it reloads the imx296 module and restarts nvargus-daemon).
RELOAD_SCRIPT="${PKG_DIR}/scripts/install_imx296_reload_service.sh"
if [ -x "$RELOAD_SCRIPT" ]; then
    echo "=== Installing imx296-reload.service ==="
    "$RELOAD_SCRIPT" || echo "WARNING: reload-service install failed (non-fatal)"
else
    echo "WARNING: ${RELOAD_SCRIPT} not found or not executable"
fi

cat <<EOF

Installed (unified: color + mono):
  ${I2C_MODULE_DIR}/imx296.ko        (auto-detects color/mono)
  ${TEGRA_CAMERA_MODULE}             (Y10-patched, color-compatible)
  /boot/tegra234-p3767-camera-p3768-imx296-{cam0,cam1,dual}.dtbo       (color, RG10)
  /boot/tegra234-p3767-camera-p3768-imx296mono-{cam0,cam1,dual}.dtbo   (mono,  Y10)
  /etc/systemd/system/imx296-reload.service                            (enabled; reloads module + daemon each boot)

NEXT: enable ONE overlay = pick color or mono (the driver auto-detects the chip).
Recommended (non-interactive, writes a correct FDT+OVERLAYS label).
Header 2 = the 22pin CSI Connector (header 1 = 40pin GPIO); run -l to confirm:
  sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -l    # list headers + exact names

  # COLOR (RG10):
  sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX296-C Cam0'           # CAM0 only
  sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX296-C Cam1'           # CAM1 only
  sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX296-C and IMX296-C'   # both

  # MONO (Y10):
  sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX296LLR-Mono Y10 Cam0'                    # CAM0 only
  sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX296LLR-Mono Y10 Cam1'                    # CAM1 only
  sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX296LLR-Mono Y10 and IMX296LLR-Mono Y10'  # both

  sudo reboot   # enable only ONE of the above, then reboot
Or interactively: sudo /opt/nvidia/jetson-io/jetson-io.py
Do NOT hand-edit extlinux.conf (a label without FDT silently ignores OVERLAYS).
EOF
