#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACKAGE_DIR="$(dirname "$SCRIPT_DIR")"
KERNEL_VERSION="$(uname -r)"
I2C_MODULE_DIR="/lib/modules/${KERNEL_VERSION}/kernel/drivers/media/i2c"
TEGRA_CAMERA_MODULE="/lib/modules/${KERNEL_VERSION}/updates/drivers/media/platform/tegra/camera/tegra-camera.ko"
DTBO_NAME="tegra234-p3767-camera-p3768-imx296mono-y10-imx296mono-y10.dtbo"
BACKUP_DIR="/opt/imx296-y10-backup-$(date +%Y%m%d%H%M%S)"

echo "================================================="
echo "IMX296LLR Mono Y10 Driver Installation"
echo "================================================="
echo "Kernel: ${KERNEL_VERSION}"
echo ""
echo "This package installs:"
echo "  - imx296.ko"
echo "  - tegra-camera.ko"
echo "  - ${DTBO_NAME}"
echo ""
echo "A rollback copy will be saved under:"
echo "  ${BACKUP_DIR}"
echo ""

if [ "$KERNEL_VERSION" != "5.15.148-tegra" ]; then
    echo "ERROR: this binary is only for 5.15.148-tegra." >&2
    exit 1
fi

for f in \
    "${PACKAGE_DIR}/binary/imx296.ko" \
    "${PACKAGE_DIR}/binary/tegra-camera.ko" \
    "${PACKAGE_DIR}/binary/${DTBO_NAME}"; do
    if [ ! -f "$f" ]; then
        echo "ERROR: missing $f" >&2
        exit 1
    fi
done

sudo mkdir -p "$BACKUP_DIR"

if [ -f "${I2C_MODULE_DIR}/imx296.ko" ]; then
    sudo cp -a "${I2C_MODULE_DIR}/imx296.ko" "${BACKUP_DIR}/imx296.ko"
fi

if [ -f "${TEGRA_CAMERA_MODULE}" ]; then
    sudo cp -a "${TEGRA_CAMERA_MODULE}" "${BACKUP_DIR}/tegra-camera.ko"
else
    echo "ERROR: installed tegra-camera.ko not found: ${TEGRA_CAMERA_MODULE}" >&2
    exit 1
fi

sudo find /boot -maxdepth 1 -type f -name '*imx296*.dtbo' -exec cp -a {} "$BACKUP_DIR"/ \;

sudo install -D -m 0644 "${PACKAGE_DIR}/binary/imx296.ko" "${I2C_MODULE_DIR}/imx296.ko"
sudo install -D -m 0644 "${PACKAGE_DIR}/binary/tegra-camera.ko" "${TEGRA_CAMERA_MODULE}"
sudo install -m 0644 "${PACKAGE_DIR}/binary/${DTBO_NAME}" "/boot/${DTBO_NAME}"
sudo find /boot -maxdepth 1 -type f -name '*imx296*.dtbo' ! -name "${DTBO_NAME}" -print -delete
sudo depmod -a

cat <<EOF

Installation completed.

Jetson-IO overlay display name:
  Camera IMX296LLR-Mono Y10 and IMX296LLR-Mono Y10

Next:
  sudo /opt/nvidia/jetson-io/jetson-io.py
  sudo reboot

After reboot, verify:
  v4l2-ctl -d /dev/video0 --list-formats-ext
  v4l2-ctl -d /dev/video1 --list-formats-ext

Rollback backup:
  ${BACKUP_DIR}
EOF
