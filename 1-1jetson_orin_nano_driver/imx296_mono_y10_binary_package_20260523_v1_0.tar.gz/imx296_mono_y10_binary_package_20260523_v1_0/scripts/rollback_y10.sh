#!/bin/bash
set -euo pipefail

if [ $# -ne 1 ]; then
    echo "Usage: $0 /opt/imx296-y10-backup-YYYYmmddHHMMSS" >&2
    exit 1
fi

BACKUP_DIR="$1"
KERNEL_VERSION="$(uname -r)"
I2C_MODULE_DIR="/lib/modules/${KERNEL_VERSION}/kernel/drivers/media/i2c"
TEGRA_CAMERA_MODULE="/lib/modules/${KERNEL_VERSION}/updates/drivers/media/platform/tegra/camera/tegra-camera.ko"

if [ ! -d "$BACKUP_DIR" ]; then
    echo "ERROR: backup directory not found: $BACKUP_DIR" >&2
    exit 1
fi

if [ -f "${BACKUP_DIR}/imx296.ko" ]; then
    sudo install -D -m 0644 "${BACKUP_DIR}/imx296.ko" "${I2C_MODULE_DIR}/imx296.ko"
fi

if [ -f "${BACKUP_DIR}/tegra-camera.ko" ]; then
    sudo install -D -m 0644 "${BACKUP_DIR}/tegra-camera.ko" "${TEGRA_CAMERA_MODULE}"
fi

sudo find /boot -maxdepth 1 -type f -name '*imx296*.dtbo' -print -delete
if compgen -G "${BACKUP_DIR}/*.dtbo" >/dev/null; then
    sudo cp -a "${BACKUP_DIR}"/*.dtbo /boot/
fi

sudo depmod -a

echo "Rollback completed. Re-select the previous overlay if needed, then reboot."
