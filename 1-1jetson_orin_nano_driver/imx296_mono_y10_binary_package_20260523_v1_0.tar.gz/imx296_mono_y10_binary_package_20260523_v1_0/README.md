# IMX296LLR Mono Y10 Binary Driver Package v1.0

Package: `imx296_mono_y10_binary_package_20260523_v1_0.tar.gz`

Target: Jetson Orin Nano/NX, L4T r36.4.4, kernel `5.15.148-tegra`

Use this package for dual IMX296LLR mono modules when the V4L2 format should
be reported as grayscale `Y10`.

## Contents

```text
binary/
  imx296.ko
  tegra-camera.ko
  tegra234-p3767-camera-p3768-imx296mono-y10-imx296mono-y10.dtbo
scripts/
  install_y10.sh
  rollback_y10.sh
  camera_control_mono.sh
```

## Install

```bash
tar -xzf imx296_mono_y10_binary_package_20260523_v1_0.tar.gz
cd imx296_mono_y10_binary_package_20260523_v1_0/scripts
chmod +x *.sh
./install_y10.sh
```

Select this Jetson-IO overlay, save, and reboot:

```text
Camera IMX296LLR-Mono Y10 and IMX296LLR-Mono Y10
```

## Verify

After reboot:

```bash
v4l2-ctl -d /dev/video0 --list-formats-ext
v4l2-ctl -d /dev/video1 --list-formats-ext
```

Expected format:

```text
Y10  10-bit Greyscale
```

Raw capture:

```bash
cd scripts
DEVICE=/dev/video0 ./camera_control_mono.sh capture cam0_y10
DEVICE=/dev/video1 ./camera_control_mono.sh capture cam1_y10
```

The script writes `.raw`, `.pgm`, and, when OpenCV is available, `.png` files.

## Rollback

The install script prints a backup directory such as:

```text
/opt/imx296-y10-backup-YYYYmmddHHMMSS
```

Rollback:

```bash
./rollback_y10.sh /opt/imx296-y10-backup-YYYYmmddHHMMSS
sudo reboot
```

